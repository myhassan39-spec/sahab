package com.sahab.downloader

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val _downloads = MutableStateFlow<List<DownloadItem>>(emptyList())
    val downloads: StateFlow<List<DownloadItem>> = _downloads.asStateFlow()

    private val jobs = mutableMapOf<String, Job>()
    private val cancelled = mutableSetOf<String>()

    private fun str(id: Int, vararg args: Any) = getApplication<Application>().getString(id, *args)

    fun onUrlChange(s: String) = _ui.update { it.copy(url = s) }
    fun clearUrl() = _ui.update { UiState() }
    fun setTab(i: Int) = _ui.update { it.copy(tab = i) }

    /** يستقبل نصاً (من اللصق أو المشاركة)، يستخرج الرابط ويحلّله مباشرة. */
    fun handleShared(text: String) {
        val url = extractUrl(text) ?: text.trim()
        _ui.update { it.copy(url = url) }
        analyze()
    }

    fun analyze() {
        val url = extractUrl(_ui.value.url)
        if (url == null) {
            _ui.update { it.copy(error = str(R.string.err_bad_url), info = null) }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null, info = null) }
            try {
                SahabApp.ready.first { it }
                val info = MediaRepository.fetch(url)
                val tab = when {
                    info.videos.isNotEmpty() -> 0
                    info.audios.isNotEmpty() -> 1
                    else -> 2
                }
                _ui.update { it.copy(loading = false, info = info, tab = tab) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, error = str(R.string.err_analyze, e.short())) }
            }
        }
    }

    fun download(choice: Choice, label: String) {
        val info = _ui.value.info ?: return
        val id = UUID.randomUUID().toString()
        _downloads.update { listOf(DownloadItem(id, info.title, label)) + it }

        jobs[id] = viewModelScope.launch {
            try {
                val saved = MediaRepository.download(getApplication(), info, choice, id) { p, eta ->
                    patch(id) { it.copy(progress = p, etaSec = eta) }
                }
                patch(id) {
                    it.copy(status = Status.Done, progress = 100f, uri = saved.uri, mime = saved.mime)
                }
            } catch (e: CancellationException) {
                patch(id) { it.copy(status = Status.Cancelled) }
                throw e
            } catch (e: Exception) {
                if (id in cancelled) patch(id) { it.copy(status = Status.Cancelled) }
                else patch(id) { it.copy(status = Status.Failed, message = e.short()) }
            } finally {
                jobs.remove(id)
                cancelled.remove(id)
                syncService()
            }
        }
        syncService()
    }

    fun cancel(id: String) {
        cancelled.add(id)
        try {
            YoutubeDL.getInstance().destroyProcessById(id)
        } catch (_: Exception) {
        }
        jobs[id]?.cancel()
    }

    fun clearFinished() = _downloads.update { list -> list.filter { it.status == Status.Running } }

    private fun patch(id: String, f: (DownloadItem) -> DownloadItem) =
        _downloads.update { list -> list.map { if (it.id == id) f(it) else it } }

    private fun syncService() {
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, DownloadService::class.java)
        if (jobs.isNotEmpty()) ContextCompat.startForegroundService(ctx, intent) else ctx.stopService(intent)
    }

    private fun Throwable.short(): String =
        message?.lines()?.lastOrNull { it.isNotBlank() }?.take(220) ?: javaClass.simpleName
}
