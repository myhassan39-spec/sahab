package com.sahab.downloader.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.sahab.downloader.Choice
import com.sahab.downloader.DownloadItem
import com.sahab.downloader.MainViewModel
import com.sahab.downloader.MediaInfo
import com.sahab.downloader.R
import com.sahab.downloader.SahabApp
import com.sahab.downloader.Status
import com.sahab.downloader.formatDuration
import com.sahab.downloader.formatSize
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    val ready by SahabApp.ready.collectAsStateWithLifecycle()
    val engineError by SahabApp.initError.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val focus = LocalFocusManager.current

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(R.string.app_name), fontWeight = FontWeight.Bold, fontSize = 22.sp)
                        Text(
                            stringResource(R.string.tagline),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                LinkCard(
                    url = ui.url,
                    enabled = !ui.loading,
                    onChange = vm::onUrlChange,
                    onPaste = { clipboard.getText()?.text?.let(vm::handleShared) },
                    onClear = vm::clearUrl,
                    onAnalyze = {
                        focus.clearFocus()
                        vm.analyze()
                    },
                )
            }

            if (engineError != null) {
                item { Notice(stringResource(R.string.engine_failed, engineError ?: ""), isError = true) }
            } else if (!ready) {
                item { Notice(stringResource(R.string.loading_engine)) }
            }

            ui.error?.let { msg -> item { Notice(msg, isError = true) } }

            if (ui.loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }

            ui.info?.let { info ->
                item { InfoHeader(info) }
                item {
                    TabRow(selectedTabIndex = ui.tab, containerColor = Color.Transparent) {
                        Tab(
                            selected = ui.tab == 0,
                            onClick = { vm.setTab(0) },
                            text = { Text(stringResource(R.string.tab_video, info.videos.size)) },
                        )
                        Tab(
                            selected = ui.tab == 1,
                            onClick = { vm.setTab(1) },
                            text = { Text(stringResource(R.string.tab_audio, info.audios.size)) },
                        )
                        Tab(
                            selected = ui.tab == 2,
                            onClick = { vm.setTab(2) },
                            text = { Text(stringResource(R.string.tab_image, info.images.size)) },
                        )
                    }
                }

                when (ui.tab) {
                    0 -> {
                        if (info.videos.isEmpty()) {
                            item { Notice(stringResource(R.string.empty_video)) }
                        } else {
                            items(info.videos) { v ->
                                OptionRow(
                                    title = v.quality,
                                    tags = listOfNotNull(v.ext.uppercase(Locale.US), v.codec),
                                    note = stringResource(if (v.needsMerge) R.string.note_merge else R.string.note_progressive),
                                    size = formatSize(v.sizeBytes, v.sizeEstimated),
                                    onClick = {
                                        vm.download(Choice.Video(v), "${v.quality} · ${v.ext.uppercase(Locale.US)}")
                                    },
                                )
                            }
                        }
                    }

                    1 -> {
                        if (info.audios.isEmpty()) {
                            item { Notice(stringResource(R.string.empty_audio)) }
                        } else {
                            items(info.audios) { a ->
                                OptionRow(
                                    title = a.label,
                                    tags = listOfNotNull(a.ext.uppercase(Locale.US), a.codec),
                                    note = stringResource(
                                        if (a.convertToMp3Kbps != null) R.string.note_audio_convert else R.string.note_audio_native
                                    ),
                                    size = formatSize(a.sizeBytes, a.sizeEstimated),
                                    onClick = { vm.download(Choice.Audio(a), a.label) },
                                )
                            }
                        }
                    }

                    else -> {
                        if (info.images.isEmpty()) {
                            item { Notice(stringResource(R.string.empty_image)) }
                        } else {
                            items(info.images) { img ->
                                val dims = if (img.width > 0) "${img.width}×${img.height}"
                                else stringResource(R.string.image_original)
                                val title = if (img.index > 0) "${stringResource(R.string.image_n, img.index)} · $dims" else dims
                                OptionRow(
                                    title = title,
                                    tags = listOf(img.ext.uppercase(Locale.US)),
                                    note = null,
                                    size = formatSize(img.sizeBytes),
                                    onClick = { vm.download(Choice.Image(img), title) },
                                )
                            }
                        }
                    }
                }
            }

            if (downloads.isNotEmpty()) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            stringResource(R.string.downloads),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        TextButton(onClick = vm::clearFinished) { Text(stringResource(R.string.clear_finished)) }
                    }
                }
                items(downloads, key = { it.id }) { d ->
                    DownloadRow(d, onCancel = { vm.cancel(d.id) })
                }
            }

            item {
                Text(
                    stringResource(R.string.legal_note),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                )
            }
        }
    }
}

@Composable
private fun LinkCard(
    url: String,
    enabled: Boolean,
    onChange: (String) -> Unit,
    onPaste: () -> Unit,
    onClear: () -> Unit,
    onAnalyze: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = url,
                onValueChange = onChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(stringResource(R.string.hint_link)) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                leadingIcon = { Icon(Icons.Rounded.Link, contentDescription = null) },
                trailingIcon = {
                    if (url.isNotEmpty()) {
                        IconButton(onClick = onClear) {
                            Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.clear))
                        }
                    } else {
                        IconButton(onClick = onPaste) {
                            Icon(Icons.Rounded.ContentPaste, contentDescription = stringResource(R.string.paste))
                        }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                keyboardActions = KeyboardActions(onGo = { onAnalyze() }),
            )
            Button(
                onClick = onAnalyze,
                enabled = enabled && url.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
            ) {
                Icon(Icons.Rounded.Search, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.analyze), fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun Notice(text: String, isError: Boolean = false) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isError) MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
            else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Text(
            text,
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            style = MaterialTheme.typography.bodyMedium,
            color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun InfoHeader(info: MediaInfo) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (info.thumbnail != null) {
                AsyncImage(
                    model = info.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(width = 128.dp, height = 76.dp).clip(RoundedCornerShape(12.dp)),
                )
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    info.title,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold,
                )
                val meta = listOfNotNull(info.uploader, formatDuration(info.durationSec).ifBlank { null })
                    .joinToString(" · ")
                if (meta.isNotBlank()) {
                    Text(
                        meta,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
private fun OptionRow(
    title: String,
    tags: List<String>,
    note: String?,
    size: String,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    tags.forEach { t ->
                        Text(
                            t,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                        )
                    }
                }
                if (note != null) {
                    Text(
                        note,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Text(size, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            FilledTonalIconButton(onClick = onClick) {
                Icon(Icons.Rounded.Download, contentDescription = stringResource(R.string.downloads))
            }
        }
    }
}

@Composable
private fun DownloadRow(d: DownloadItem, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(d.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(
                d.label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            when (d.status) {
                Status.Running -> {
                    if (d.progress < 0) LinearProgressIndicator(Modifier.fillMaxWidth())
                    else LinearProgressIndicator(progress = { d.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        val pct = if (d.progress >= 0) String.format(Locale.US, "%.0f%%", d.progress) else ""
                        val eta = if (d.etaSec > 0) " · " + stringResource(R.string.eta, formatDuration(d.etaSec)) else ""
                        Text(pct + eta, style = MaterialTheme.typography.labelMedium)
                        TextButton(onClick = onCancel) { Text(stringResource(R.string.cancel)) }
                    }
                }

                Status.Done -> Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                        Text(stringResource(R.string.status_done), style = MaterialTheme.typography.labelMedium)
                    }
                    if (d.uri != null) {
                        TextButton(onClick = { openFile(ctx, d.uri, d.mime) }) { Text(stringResource(R.string.open)) }
                    }
                }

                Status.Failed -> Text(
                    stringResource(R.string.status_failed, d.message ?: ""),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error,
                )

                Status.Cancelled -> Text(
                    stringResource(R.string.status_cancelled),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun openFile(ctx: Context, uri: Uri, mime: String?) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime ?: "*/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: ActivityNotFoundException) {
    }
}
