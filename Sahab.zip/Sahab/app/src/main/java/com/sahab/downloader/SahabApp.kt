package com.sahab.downloader

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.flow.MutableStateFlow

class SahabApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val ctx = applicationContext
        Thread {
            try {
                YoutubeDL.getInstance().init(ctx)
                FFmpeg.getInstance().init(ctx)

                // المنصات تغيّر واجهاتها كثيراً، فنحدّث yt-dlp مرة كل 24 ساعة قبل الاستخدام.
                val prefs = ctx.getSharedPreferences("sahab", MODE_PRIVATE)
                val last = prefs.getLong("last_update", 0L)
                if (System.currentTimeMillis() - last > 24L * 3600 * 1000) {
                    try {
                        YoutubeDL.getInstance().updateYoutubeDL(ctx)
                        prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
                    } catch (_: Exception) {
                        // لا مشكلة: نكمل بالنسخة المضمّنة
                    }
                }
                ready.value = true
            } catch (e: Exception) {
                initError.value = e.message ?: e.javaClass.simpleName
            }
        }.start()
    }

    companion object {
        val ready = MutableStateFlow(false)
        val initError = MutableStateFlow<String?>(null)
    }
}
