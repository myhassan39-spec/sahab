package com.sahab.downloader

import android.net.Uri

data class VideoOption(
    val id: String,
    val quality: String,
    val ext: String,
    val codec: String?,
    val sizeBytes: Long?,
    val sizeEstimated: Boolean,
    val needsMerge: Boolean,
    val height: Int,
)

data class AudioOption(
    val id: String?,
    val label: String,
    val ext: String,
    val codec: String?,
    val bitrate: Int,
    val sizeBytes: Long?,
    val sizeEstimated: Boolean,
    val convertToMp3Kbps: Int?,
)

data class ImageOption(
    val url: String,
    val ext: String,
    val width: Int,
    val height: Int,
    val sizeBytes: Long?,
    val index: Int,
)

data class MediaInfo(
    val url: String,
    val title: String,
    val uploader: String?,
    val durationSec: Long,
    val thumbnail: String?,
    val videos: List<VideoOption>,
    val audios: List<AudioOption>,
    val images: List<ImageOption>,
)

sealed interface Choice {
    data class Video(val opt: VideoOption) : Choice
    data class Audio(val opt: AudioOption) : Choice
    data class Image(val opt: ImageOption) : Choice
}

enum class Status { Running, Done, Failed, Cancelled }

data class DownloadItem(
    val id: String,
    val title: String,
    val label: String,
    val progress: Float = -1f,
    val etaSec: Long = 0,
    val status: Status = Status.Running,
    val message: String? = null,
    val uri: Uri? = null,
    val mime: String? = null,
)

data class SavedFile(val uri: Uri?, val name: String, val mime: String)

data class UiState(
    val url: String = "",
    val loading: Boolean = false,
    val error: String? = null,
    val info: MediaInfo? = null,
    val tab: Int = 0,
)
