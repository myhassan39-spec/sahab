package com.sahab.downloader

import java.util.Locale

fun formatSize(bytes: Long?, estimated: Boolean = false): String {
    if (bytes == null || bytes <= 0) return "—"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = 0
    while (v >= 1024 && i < units.lastIndex) {
        v /= 1024
        i++
    }
    val num = if (i <= 1) String.format(Locale.US, "%.0f", v) else String.format(Locale.US, "%.1f", v)
    return (if (estimated) "~" else "") + num + " " + units[i]
}

fun formatDuration(sec: Long): String {
    if (sec <= 0) return ""
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

fun extractUrl(text: String): String? =
    Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')', '،', '؛')
