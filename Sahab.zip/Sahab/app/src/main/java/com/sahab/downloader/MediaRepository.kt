package com.sahab.downloader

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object MediaRepository {

    private val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "avif")
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    // ───────────────────────── تحليل الرابط ─────────────────────────

    suspend fun fetch(url: String): MediaInfo = withContext(Dispatchers.IO) {
        directImageExt(url)?.let { return@withContext directImage(url, it) }

        val req = YoutubeDLRequest(url).apply {
            addOption("-J")
            addOption("--no-playlist")
            addOption("--no-warnings")
        }
        val out = YoutubeDL.getInstance().execute(req).out
        val start = out.indexOf('{')
        require(start >= 0) { "empty response" }
        parse(url, JSONObject(out.substring(start)))
    }

    private fun directImageExt(url: String): String? {
        val path = url.substringBefore('?').substringBefore('#').lowercase()
        return path.substringAfterLast('.', "").takeIf { it in IMAGE_EXTS }
    }

    private fun directImage(url: String, ext: String): MediaInfo {
        val name = url.substringBefore('?').substringAfterLast('/')
            .substringBeforeLast('.').ifBlank { "image" }
        val size = runCatching {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"
            c.setRequestProperty("User-Agent", UA)
            c.connectTimeout = 10000
            c.readTimeout = 10000
            val l = c.contentLengthLong
            c.disconnect()
            l.takeIf { it > 0 }
        }.getOrNull()
        val img = ImageOption(url, ext, 0, 0, size, 0)
        return MediaInfo(url, name, null, 0, url, emptyList(), emptyList(), listOf(img))
    }

    private fun JSONObject.str(k: String): String? =
        if (isNull(k)) null else optString(k).takeIf { it.isNotBlank() }

    private fun JSONObject.lng(k: String): Long? =
        if (isNull(k)) null else optLong(k, 0L).takeIf { it > 0 }

    private fun parse(url: String, j: JSONObject): MediaInfo {
        val entries = j.optJSONArray("entries")
        val isCollection = entries != null && entries.length() > 0 && j.optJSONArray("formats") == null
        val first = if (isCollection) (entries!!.optJSONObject(0) ?: j) else j

        val duration = first.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() }
        val title = j.str("title") ?: first.str("title") ?: "download"
        val (videos, audios) = parseFormats(first.optJSONArray("formats"), duration)
        val images = if (isCollection) entryImages(entries!!) else thumbs(first)

        return MediaInfo(
            url = url,
            title = title,
            uploader = j.str("uploader") ?: first.str("uploader") ?: first.str("channel"),
            durationSec = duration,
            thumbnail = j.str("thumbnail") ?: first.str("thumbnail"),
            videos = videos,
            audios = audios,
            images = images,
        )
    }

    private fun extOf(url: String): String = directImageExt(url) ?: "jpg"

    private fun thumbs(o: JSONObject): List<ImageOption> {
        val list = mutableListOf<ImageOption>()
        val arr = o.optJSONArray("thumbnails")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val t = arr.optJSONObject(i) ?: continue
                val u = t.str("url") ?: continue
                list += ImageOption(u, extOf(u), t.optInt("width", 0), t.optInt("height", 0), null, 0)
            }
        }
        if (list.isEmpty()) {
            o.str("thumbnail")?.let { list += ImageOption(it, extOf(it), 0, 0, null, 0) }
        }
        return list.distinctBy { it.url }.sortedByDescending { it.width.toLong() * it.height }
    }

    private fun entryImages(entries: JSONArray): List<ImageOption> {
        val list = mutableListOf<ImageOption>()
        for (i in 0 until entries.length()) {
            val e = entries.optJSONObject(i) ?: continue
            val direct = e.str("url")?.takeIf { directImageExt(it) != null }
            val best = if (direct != null) {
                ImageOption(direct, extOf(direct), e.optInt("width", 0), e.optInt("height", 0), null, i + 1)
            } else {
                thumbs(e).firstOrNull()?.copy(index = i + 1)
            }
            if (best != null) list += best
        }
        return list
    }

    private class F(
        val id: String, val ext: String, val h: Int, val fps: Int,
        val vc: String?, val ac: String?, val size: Long?, val est: Boolean,
        val abr: Int, val note: String?, val hasV: Boolean, val hasA: Boolean,
    )

    private fun parseFormats(arr: JSONArray?, duration: Long): Pair<List<VideoOption>, List<AudioOption>> {
        if (arr == null) return emptyList<VideoOption>() to emptyList()

        val fs = ArrayList<F>()
        for (i in 0 until arr.length()) {
            val f = arr.optJSONObject(i) ?: continue
            val id = f.str("format_id") ?: continue
            val ext = f.str("ext") ?: continue
            if (ext == "mhtml" || f.str("protocol") == "mhtml") continue

            val vc = f.str("vcodec")
            val ac = f.str("acodec")
            val h = f.optInt("height", 0)
            val hasV = (vc != null && vc != "none") || (vc == null && h > 0)
            val hasA = ac != "none"
            if (!hasV && !hasA) continue

            val tbr = f.optDouble("tbr", 0.0).let { if (it.isNaN()) 0.0 else it }
            val abrRaw = f.optDouble("abr", 0.0).let { if (it.isNaN()) 0.0 else it }
            val abr = (if (abrRaw > 0) abrRaw else if (!hasV) tbr else 0.0).toInt()

            var size = f.lng("filesize") ?: f.lng("filesize_approx")
            var est = false
            if (size == null && tbr > 0 && duration > 0) {
                size = (tbr * 125 * duration).toLong()
                est = true
            }
            fs += F(id, ext, h, f.optInt("fps", 0), vc, ac, size, est, abr, f.str("format_note"), hasV, hasA)
        }

        val bestAudio = fs.filter { !it.hasV && it.hasA }.maxByOrNull { it.abr }

        val videos = fs.filter { it.hasV }.map { f ->
            val merge = !f.hasA
            val total = f.size?.let { it + (if (merge) (bestAudio?.size ?: 0L) else 0L) }
            VideoOption(
                id = f.id,
                quality = qualityLabel(f.h, f.fps, f.note),
                ext = f.ext,
                codec = codecName(f.vc),
                sizeBytes = total,
                sizeEstimated = f.est || (merge && bestAudio?.est == true),
                needsMerge = merge,
                height = f.h,
            )
        }
            .groupBy { listOf(it.quality, it.ext, it.codec, it.needsMerge) }
            .map { (_, g) -> g.maxByOrNull { it.sizeBytes ?: 0L }!! }
            .sortedWith(
                compareByDescending<VideoOption> { it.height }
                    .thenBy { if (it.ext == "mp4") 0 else 1 }
                    .thenByDescending { it.sizeBytes ?: 0L }
            )

        val nativeAudio = fs.filter { !it.hasV && it.hasA }.map { f ->
            AudioOption(
                id = f.id,
                label = if (f.abr > 0) "${f.abr} kbps" else (f.note ?: f.id),
                ext = f.ext,
                codec = codecName(f.ac),
                bitrate = f.abr,
                sizeBytes = f.size,
                sizeEstimated = f.est,
                convertToMp3Kbps = null,
            )
        }
            .groupBy { it.ext to it.label }
            .map { (_, g) -> g.maxByOrNull { it.sizeBytes ?: 0L }!! }
            .sortedByDescending { it.bitrate }

        val mp3 = if (fs.isEmpty()) emptyList() else listOf(320, 192, 128).map { kbps ->
            AudioOption(
                id = null,
                label = "MP3 · $kbps kbps",
                ext = "mp3",
                codec = "MP3",
                bitrate = kbps,
                sizeBytes = if (duration > 0) duration * kbps * 125L else null,
                sizeEstimated = true,
                convertToMp3Kbps = kbps,
            )
        }

        return videos to (nativeAudio + mp3)
    }

    private fun qualityLabel(h: Int, fps: Int, note: String?): String =
        if (h > 0) "${h}p" + (if (fps > 30) fps.toString() else "") else (note ?: "Auto")

    private fun codecName(c: String?): String? {
        if (c == null || c == "none") return null
        val l = c.lowercase()
        return when {
            l.startsWith("avc1") || l.startsWith("h264") -> "H.264"
            l.startsWith("vp09") || l.startsWith("vp9") -> "VP9"
            l.startsWith("av01") -> "AV1"
            l.startsWith("hev1") || l.startsWith("hvc1") || l.startsWith("hevc") -> "H.265"
            l.startsWith("mp4a") -> "AAC"
            l.startsWith("opus") -> "Opus"
            else -> c.substringBefore('.')
        }
    }

    // ───────────────────────── التنزيل ─────────────────────────

    suspend fun download(
        ctx: Context,
        info: MediaInfo,
        choice: Choice,
        processId: String,
        onProgress: (Float, Long) -> Unit,
    ): SavedFile = withContext(Dispatchers.IO) {
        val tmp = File(ctx.cacheDir, "dl/$processId").apply { mkdirs() }
        try {
            val file = when (choice) {
                is Choice.Image -> fetchImage(tmp, info.title, choice.opt, onProgress)
                else -> runYtDlp(tmp, info.url, choice, processId, onProgress)
            }
            saveToDownloads(ctx, file)
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun ytdlpArgs(c: Choice): List<List<String>> = when (c) {
        is Choice.Video -> {
            val o = c.opt
            if (o.needsMerge) {
                val aud = if (o.ext == "mp4") "bestaudio[ext=m4a]/bestaudio" else "bestaudio"
                listOf(
                    listOf("-f", "${o.id}+$aud/${o.id}"),
                    listOf("--merge-output-format", if (o.ext == "mp4") "mp4" else "mkv"),
                )
            } else {
                listOf(listOf("-f", o.id))
            }
        }
        is Choice.Audio -> {
            val o = c.opt
            if (o.convertToMp3Kbps != null) listOf(
                listOf("-f", "bestaudio/best"),
                listOf("-x"),
                listOf("--audio-format", "mp3"),
                listOf("--audio-quality", "${o.convertToMp3Kbps}K"),
            ) else listOf(listOf("-f", o.id ?: "bestaudio/best"))
        }
        is Choice.Image -> emptyList()
    }

    private fun runYtDlp(
        dir: File, url: String, choice: Choice, processId: String,
        onProgress: (Float, Long) -> Unit,
    ): File {
        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        req.addOption("--no-mtime")
        req.addOption("--trim-filenames", "120")
        req.addOption("-o", "${dir.absolutePath}/%(title)s.%(ext)s")
        for (a in ytdlpArgs(choice)) {
            if (a.size == 1) req.addOption(a[0]) else req.addOption(a[0], a[1])
        }
        YoutubeDL.getInstance().execute(req, processId) { progress, eta, _ ->
            if (progress >= 0) onProgress(progress, eta)
        }
        return dir.listFiles()
            ?.filter {
                it.isFile &&
                    !it.name.endsWith(".part") &&
                    !it.name.endsWith(".ytdl") &&
                    !it.name.endsWith(".temp") &&
                    !it.name.matches(Regex(".*\\.f\\d+\\..*")) // ملفات وسيطة قبل الدمج
            }
            ?.maxByOrNull { it.length() }
            ?: error("no output file")
    }

    private suspend fun fetchImage(
        dir: File, title: String, o: ImageOption, onProgress: (Float, Long) -> Unit,
    ): File {
        val suffix = when {
            o.width > 0 -> "_${o.width}x${o.height}"
            o.index > 0 -> "_${o.index}"
            else -> ""
        }
        val out = File(dir, safeName(title) + suffix + "." + o.ext)
        val conn = (URL(o.url).openConnection() as HttpURLConnection).apply {
            setRequestProperty("User-Agent", UA)
            connectTimeout = 15000
            readTimeout = 30000
            instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(32 * 1024)
                    var done = 0L
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = ins.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress(done * 100f / total, 0)
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
        return out
    }

    private fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(80).ifBlank { "download" }

    private fun mimeOf(file: File): String {
        val ext = file.extension.lowercase()
        if (ext == "mkv") return "video/x-matroska"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun saveToDownloads(ctx: Context, file: File): SavedFile {
        val mime = mimeOf(file)
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/Sahab")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("cannot create file in Downloads")
            resolver.openOutputStream(uri)!!.use { os -> file.inputStream().use { it.copyTo(os) } }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return SavedFile(uri, file.name, mime)
        }
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Sahab")
        dir.mkdirs()
        var dest = File(dir, file.name)
        var n = 1
        while (dest.exists()) {
            dest = File(dir, "${file.nameWithoutExtension} ($n).${file.extension}")
            n++
        }
        file.copyTo(dest)
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.path), null, null)
        return SavedFile(null, dest.name, mime)
    }
}
